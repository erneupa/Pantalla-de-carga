# nc-loadingscreen // #1

- In the loading screen you have the option to see a date, number of players online to the server, description of the server, staff and lots of other things that you can see in the video below.
- If you need help you can join to ur discord - https://discord.gg/NCHub

## Video & Screenshot

- click - https://streamable.com/s1hwk8
![nc-loadingscreen](https://i.ibb.co/h9L9TNS/Screenshot-1.png)
