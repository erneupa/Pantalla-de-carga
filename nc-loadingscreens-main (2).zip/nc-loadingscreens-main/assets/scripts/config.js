Config = {}; // Don't touch

Config.ServerIP = "Su IP del servidor";

// Social media buttons on the left side
Config.Socials = [
    {name: "Discord", label: "Discord", description: "¡Haz clic aquí para copiar el enlace y unirte a nuestro servidor de Discord!", icon: "assets/media/icons/discord.png", link: "https://discord.gg/yJJvcZ8FAD"},
    {name: "TikTok", label: "TikTok", description: "¡Hecha un vistazo a nuestro TikTok!", icon: "assets/media/icons/tiktok.png", link: "#"},
    {name: "Paypal", label: "Donaciones", description: "Para donaciones, no dudes en mirar la sala #Donations en Discord.", icon: "assets/media/icons/tebex.png", link: "#"},
];




Config.HideoverlayKeybind = 112 // JS key code https://keycode.info
Config.CustomBindText = "F1"; // leave as "" if you don't want the bind text in html to be statically set

// Staff list
Config.Staff = [
    {name: "Don", description: "Owner", color: "#c3b062", image: "assets/media/Creadores/don.png"},
    {name: "David Borrallo", description: "Owner", color: "#c3b062", image: "assets/media/Creadores/david.png"},


];

// Categories
Config.Categories = [
    {label: "Redes sociales", default: true},
    {label: "Creadores", default: false}
];

// Music
Config.Song = "song.mp3";